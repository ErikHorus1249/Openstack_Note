console.log("EXAMPLE: your analytics js was loaded");
