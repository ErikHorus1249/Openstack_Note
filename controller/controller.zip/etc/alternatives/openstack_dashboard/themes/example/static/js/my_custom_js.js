console.log("EXAMPLE: your custom js was loaded");
